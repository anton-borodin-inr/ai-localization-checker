# Confirmed visible-text references — APK 1271048

Anton approved this exact disposition in chat on 2026-10-23:
“Да, оформить окончательный набор так”. The full question/answer and scope,
including every source candidate hash, are bound by `chat-authorization.json`
and `reference-index.json`. This is a human-approved reference artifact set;
no browser timer or checkbox action is claimed.

## Contents

20 confirmed references (ten screens × EN/DE), with 712 nonempty rows:
**441 primary / 271 diagnostic**. The 21 empty clipped placeholders remain
verbatim in the per-screen and combined diagnostic appendices, outside the
reference text projection. The original r2 candidates remain 733 rows and
are preserved unchanged. The original review/preparation packages remain.
The 25 diagnostic bullet characters and all other nonempty text, row order,
geometry, flags and regions are unchanged. No hidden input was transcribed.

Each screen directory contains `reference.json`, `approval.json`,
`confirmation.json`, exact `initial-candidate.json`, `reviewed-candidate.json`,
`original-parent-candidate.json`, `unresolved-diagnostics.json`, and the exact
PNG/dump/capture-pair bytes. `reference-index.json` identifies each reference
and its approval/candidate hashes. `files-sha256.json` lists every artifact.

## Confirmation method and timing

The user explicitly authorized confirmation in chat and accepted **unmeasured
review time**. Timing is `not_recorded`; timestamps and active/elapsed review
seconds are null. The recording timestamp is artifact provenance only.
No timed QA-benefit claim is supported by this set.

Current `l10n-reference confirm` accepts measured browser exports and rejects
missing timing. It was not invoked, patched, monkeypatched or reported as
passing for these chat approvals. This set was assembled by the task-local
builder and independently checked for approved source/candidate/pair/image/
dump hashes, exact nonempty projection and verbatim diagnostic retention.
The explicit `confirmation_format` is `explicit-chat-approval-v1`; applications
must not misreport these files as measured browser exports.

## Remaining human checks

The two D-025 scroll checks remain pending and are separate from acceptance
of these static visible-text references. No pixel investigation, device work,
APK build, provider call, detector run, label creation, metric/golden change,
repository-code edit, push or PR publication was performed.
