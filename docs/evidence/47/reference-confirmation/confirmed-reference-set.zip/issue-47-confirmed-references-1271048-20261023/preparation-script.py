"""Build the exact reference set explicitly approved by Anton in chat.

Task-local artifact preparation. Does not change or invoke the browser-only
confirmation importer, mutate repositories, or access the device/providers.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parents[2]
repo = root / 'work/checker'
sys.path.insert(0, str(repo / 'src'))
from l10n_checker.text_dump import canonical_bytes
from l10n_checker.text_reference import Candidate, child, load_pair

outputs = root / 'outputs'
prepared = outputs / 'issue-47-confirmation-preparation-20261023'
r2 = outputs / 'issue-47-review-1271048-r2'
target = outputs / 'issue-47-confirmed-references-1271048-20261023'

def raw_sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    return raw_sha(path.read_bytes())

def write_json(path, value):
    path.write_bytes(canonical_bytes(value))

def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()

assert not target.exists()
checker_head = git(repo, 'rev-parse', 'HEAD')
fork = root / 'work/Unciv'
assert checker_head == '952daa290cd0ba5877d4c4a1589f7dfde96d74c9'
assert git(repo, 'status', '--porcelain') == ''
assert git(fork, 'status', '--porcelain') == ''
assert git(fork, 'rev-parse', 'HEAD') == 'b534a8ae67c390412984869c7a03b168d532c36c'
assert git(fork, 'rev-parse', 'diag/47-render-diagnostics') == 'c8eb6fb7e42fc29cdc2b20a813f475d645fbf4be'

inventory = json.loads((prepared / 'files-sha256.json').read_bytes())
for item in inventory['files']:
    assert file_sha(child(prepared, item['file'])) == item['sha256']
index = json.loads((prepared / 'preparation-index.json').read_bytes())
assert len(index['screens']) == 20

# Validate all approved inputs before writing any final artifact.
inputs = []
for entry in index['screens']:
    folder = child(prepared, entry['directory'])
    initial_bytes = (folder / 'candidate.json').read_bytes()
    reviewed_bytes = (folder / 'proposed-candidate.json').read_bytes()
    initial = Candidate.model_validate_json(initial_bytes).model_dump()
    reviewed = Candidate.model_validate_json(reviewed_bytes).model_dump()
    assert raw_sha(initial_bytes) == entry['candidate_sha256']
    assert raw_sha(reviewed_bytes) == entry['proposed_candidate_sha256']
    assert initial_bytes == (r2 / entry['directory'] / 'candidate.json').read_bytes()
    expected_rows = [row for row in initial['rows'] if row['text_seen'].strip()]
    omitted_rows = [row for row in initial['rows'] if not row['text_seen'].strip()]
    assert reviewed['rows'] == expected_rows
    assert len({row['id'] for row in reviewed['rows']}) == len(reviewed['rows'])
    assert all(not row['primary_denominator'] and row['visibility'] != 'full' for row in omitted_rows)
    for key in initial:
        if key not in ('rows', 'parent_candidate_sha256'):
            assert reviewed[key] == initial[key], key
    if omitted_rows:
        assert reviewed['parent_candidate_sha256'] == raw_sha(initial_bytes)
    else:
        assert reviewed_bytes == initial_bytes
    appendix = json.loads((folder / 'unresolved-diagnostics.json').read_bytes())
    assert appendix['rows'] == omitted_rows
    pair, png, dump_bytes, dump = load_pair(folder / 'capture.pair.json')
    assert file_sha(folder / 'capture.pair.json') == reviewed['capture_pair_sha256']
    assert raw_sha(png) == reviewed['image']['sha256']
    assert raw_sha(dump_bytes) == reviewed['dump']['sha256']
    assert reviewed['build_version_code'] == dump.build_version_code == 1271048
    inputs.append((entry, folder, initial_bytes, reviewed_bytes, initial, reviewed, omitted_rows))
assert sum(len(item[-1]) for item in inputs) == 21
assert sum(len(item[5]['rows']) for item in inputs) == 712
assert sum(row['primary_denominator'] for item in inputs for row in item[5]['rows']) == 441

recorded_at = datetime.now(timezone.utc).isoformat()
authorization = {
    'authorization_version': 1,
    'source': 'direct_human_user_chat',
    'accepted_by': 'Anton',
    'approval_date': '2026-10-23',
    'recorded_at_utc': recorded_at,
    'question_verbatim': 'Для окончательного набора разрешаешь вынести 21 пустой обрезанный фрагмент в отдельное диагностическое приложение и оформить подтверждение на основании твоего одобрения в чате, с временем проверки «не измерено»? Все исходные r2-файлы и записи фрагментов сохранятся.',
    'answer_verbatim': 'Да, оформить окончательный набор так',
    'scope': {
        'source_pack': r2.name,
        'source_preparation_manifest_sha256': file_sha(prepared / 'files-sha256.json'),
        'source_preparation_index_sha256': file_sha(prepared / 'preparation-index.json'),
        'screens': [entry['directory'] for entry, *_ in inputs],
        'empty_diagnostic_rows_retained_separately': 21,
        'nonempty_rows_unchanged': True,
        'review_timing': 'not_recorded',
        'diagnostic_bullets_retained': 25,
        'fragment_regions_unchanged': True,
        'D025_scroll_checks': 'pending_separate_human_checks',
    },
    'review_time_note': 'Approval recording/preparation time is not human review duration. No browser checkbox/timer event is claimed.',
    'prior_chat_review_statements': json.loads((prepared / 'chat-authorization.json').read_bytes()),
}
authorization_bytes = canonical_bytes(authorization)
authorization_sha = raw_sha(authorization_bytes)
target.mkdir()
(target / 'chat-authorization.json').write_bytes(authorization_bytes)
entries = []
all_omitted = []
for entry, source, initial_bytes, reviewed_bytes, initial, reviewed, omitted_rows in inputs:
    destination = target / entry['directory']
    destination.mkdir()
    for name in ['capture.pair.json', reviewed['image']['file'], reviewed['dump']['file']]:
        shutil.copyfile(source / name, destination / name)
        assert (source / name).read_bytes() == (destination / name).read_bytes()
    (destination / 'initial-candidate.json').write_bytes(initial_bytes)
    (destination / 'reviewed-candidate.json').write_bytes(reviewed_bytes)
    shutil.copyfile(source / 'parent-candidate.json', destination / 'original-parent-candidate.json')
    appendix = {
        'status': 'retained_unresolved_diagnostics',
        'screen': reviewed['screen'], 'language': reviewed['language'],
        'initial_candidate_sha256': raw_sha(initial_bytes),
        'included_in_reference_projection': False,
        'disposition_approved_by': 'Anton',
        'authorization_sha256': authorization_sha,
        'rows': omitted_rows,
        'reason': 'Clipped placeholder without an established nonempty visible span. Preserved without guessing text from hidden input.',
    }
    write_json(destination / 'unresolved-diagnostics.json', appendix)
    timing = {
        'status': 'not_recorded', 'started_at': None, 'finished_at': None,
        'active_seconds': None, 'elapsed_seconds': None,
        'reason': 'Anton approved chat-based confirmation without measured review timing. No QA time-savings claim is made.',
    }
    approval = {
        'status': 'confirmed', 'accepted_by': 'Anton',
        'confirmation_method': 'explicit_chat_approval',
        'authorization_file': '../chat-authorization.json',
        'authorization_sha256': authorization_sha,
        'candidate_sha256': raw_sha(reviewed_bytes),
        'initial_candidate_sha256': raw_sha(initial_bytes),
        'image_sha256': reviewed['image']['sha256'],
        'dump_sha256': reviewed['dump']['sha256'],
        'capture_pair_sha256': reviewed['capture_pair_sha256'],
        'timing': timing,
        'empty_rows_retained_in_appendix': len(omitted_rows),
        'appendix_sha256': file_sha(destination / 'unresolved-diagnostics.json'),
    }
    write_json(destination / 'approval.json', approval)
    write_json(destination / 'confirmation.json', {
        'confirmation_format': 'explicit-chat-approval-v1',
        'candidate_json': reviewed_bytes.decode('utf-8'), 'approval': approval,
    })
    projection = [{
        'id': row['id'], 'text': row['text_seen'], 'region': row['region'],
        'visibility': row['visibility'], 'primary_denominator': row['primary_denominator'],
    } for row in reviewed['rows']]
    reference = {
        'status': 'confirmed', 'reference_sha256': raw_sha(reviewed_bytes),
        'screen': reviewed['screen'], 'language': reviewed['language'],
        'image': reviewed['image'], 'dump': reviewed['dump'],
        'rows': reviewed['rows'],
        'screen_texts': [row['text'] for row in projection],
        'screen_texts_source': projection,
        'limitations': reviewed['limitations'],
        'confirmation_method': 'explicit_chat_approval',
        'approval_file': 'approval.json',
        'approval_sha256': file_sha(destination / 'approval.json'),
        'review_time_status': 'not_recorded',
        'unresolved_diagnostics': {
            'file': 'unresolved-diagnostics.json',
            'sha256': approval['appendix_sha256'],
            'rows': len(omitted_rows), 'included_in_screen_texts': False,
        },
    }
    write_json(destination / 'reference.json', reference)
    entries.append({
        'directory': destination.name, 'screen': reviewed['screen'], 'language': reviewed['language'],
        'status': 'confirmed', 'reference_file': destination.name + '/reference.json',
        'reference_file_sha256': file_sha(destination / 'reference.json'),
        'reviewed_candidate_sha256': raw_sha(reviewed_bytes),
        'initial_candidate_sha256': raw_sha(initial_bytes),
        'approval_sha256': file_sha(destination / 'approval.json'),
        'rows': len(reviewed['rows']),
        'primary': sum(row['primary_denominator'] for row in reviewed['rows']),
        'diagnostic': sum(not row['primary_denominator'] for row in reviewed['rows']),
        'unresolved_rows_in_appendix': len(omitted_rows), 'review_time_status': 'not_recorded',
    })
    all_omitted.extend({'directory': destination.name, 'row': row} for row in omitted_rows)
write_json(target / 'unresolved-diagnostics-index.json', {
    'status': 'retained_unresolved_diagnostics',
    'disposition_approved_by': 'Anton', 'authorization_sha256': authorization_sha,
    'included_in_reference_projection': False, 'count': len(all_omitted), 'rows': all_omitted,
})
summary = {
    'reference_set_version': 1, 'status': 'confirmed',
    'confirmation_method': 'explicit_chat_approval',
    'authorization_file': 'chat-authorization.json', 'authorization_sha256': authorization_sha,
    'recorded_at_utc': recorded_at, 'checker_commit': checker_head,
    'fork_commit': 'b534a8ae67c390412984869c7a03b168d532c36c', 'build_version_code': 1271048,
    'source_pack': r2.name, 'parent_preparation_pack': prepared.name,
    'confirmed_screens': len(entries), 'reference_rows': sum(e['rows'] for e in entries),
    'primary': sum(e['primary'] for e in entries), 'diagnostic': sum(e['diagnostic'] for e in entries),
    'unresolved_diagnostic_rows_in_appendix': len(all_omitted),
    'source_r2_rows': 733, 'source_r2_primary': 441, 'source_r2_diagnostic': 292,
    'review_time_status': 'not_recorded', 'qa_time_savings_measured': False,
    'D025_scroll_checks': 'pending_separate_human_checks',
    'import_method': 'task-local artifact assembly under explicit chat approval; current browser-only CLI was not invoked or changed',
    'product_code_changed': False, 'device_commands': 0, 'provider_requests': 0, 'spend_usd': 0,
    'screens': entries,
}
write_json(target / 'reference-index.json', summary)
(target / 'README.md').write_text('''# Confirmed visible-text references — APK 1271048

Anton approved this exact disposition in chat on 2026-10-23:
“Да, оформить окончательный набор так”. The full question/answer and scope,
including every source candidate hash, are bound by `chat-authorization.json`
and `reference-index.json`. This is a human-approved reference artifact set;
no browser timer or checkbox action is claimed.

## Contents

20 confirmed references (ten screens × EN/DE), with 712 nonempty rows:
**441 primary / 271 diagnostic**. The 21 empty clipped placeholders remain
verbatim in the per-screen and combined diagnostic appendices, outside the
reference text projection. The original r2 candidates remain 733 rows and
are preserved unchanged. The original review/preparation packages remain.
The 25 diagnostic bullet characters and all other nonempty text, row order,
geometry, flags and regions are unchanged. No hidden input was transcribed.

Each screen directory contains `reference.json`, `approval.json`,
`confirmation.json`, exact `initial-candidate.json`, `reviewed-candidate.json`,
`original-parent-candidate.json`, `unresolved-diagnostics.json`, and the exact
PNG/dump/capture-pair bytes. `reference-index.json` identifies each reference
and its approval/candidate hashes. `files-sha256.json` lists every artifact.

## Confirmation method and timing

The user explicitly authorized confirmation in chat and accepted **unmeasured
review time**. Timing is `not_recorded`; timestamps and active/elapsed review
seconds are null. The recording timestamp is artifact provenance only.
No timed QA-benefit claim is supported by this set.

Current `l10n-reference confirm` accepts measured browser exports and rejects
missing timing. It was not invoked, patched, monkeypatched or reported as
passing for these chat approvals. This set was assembled by the task-local
builder and independently checked for approved source/candidate/pair/image/
dump hashes, exact nonempty projection and verbatim diagnostic retention.
The explicit `confirmation_format` is `explicit-chat-approval-v1`; applications
must not misreport these files as measured browser exports.

## Remaining human checks

The two D-025 scroll checks remain pending and are separate from acceptance
of these static visible-text references. No pixel investigation, device work,
APK build, provider call, detector run, label creation, metric/golden change,
repository-code edit, push or PR publication was performed.
''')
# Include the exact builder for provenance; output directories are immutable.
shutil.copyfile(Path(__file__).resolve(), target / 'preparation-script.py')
file_entries = [{
    'file': str(p.relative_to(target)), 'sha256': file_sha(p), 'bytes': p.stat().st_size,
} for p in sorted(target.rglob('*')) if p.is_file()]
write_json(target / 'files-sha256.json', {'files': file_entries})
archive = target.with_suffix('.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(target.rglob('*')):
        if p.is_file(): z.write(p, target.name + '/' + str(p.relative_to(target)))
with zipfile.ZipFile(archive) as z:
    for p in target.rglob('*'):
        if p.is_file(): assert z.read(target.name + '/' + str(p.relative_to(target))) == p.read_bytes()
assert git(repo, 'status', '--porcelain') == git(fork, 'status', '--porcelain') == ''
print(json.dumps({key: value for key, value in summary.items() if key != 'screens'}, indent=2))
print('Archive SHA-256:', file_sha(archive))
